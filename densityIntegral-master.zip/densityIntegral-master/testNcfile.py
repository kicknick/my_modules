from netCDF4 import Dataset 

def checkNum(x):
	a = ''
	for i in range(0, 6 - len(str(x))):
		a+='0'
	return a+str(x)

print(checkNum(500))
print(checkNum(1500))
print(checkNum(11500))

x = 500
for i in range(1, 500):
	n = checkNum(x)
	try: 
		ncfile = Dataset("/app/IonModel/OUTPUT/ModelRunGeo-2019-076-"+n+".nc", 'r');
		print(len(ncfile.variables['Electron_Density']), len(ncfile.variables['Geo_Lon']),  len(ncfile.variables['Geo_Radius']),  len(ncfile.variables['Geo_Lat']), n);
		x+=500
	except Exception:
		x+=500



