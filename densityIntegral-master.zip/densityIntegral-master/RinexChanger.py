import datetime
from datetime import timedelta
import math
import sys
import re
import os
import shutil
import subprocess
import georinex as gr
from netCDF4 import Dataset
from app import getIntegral

# Linux pathes
FilePath = r'/data/igs'  # initial path for observation files
path = r"/data/IGS"  # path = r"/data/IGS/" + result[len(result)-3] + r"/" + result[len(result)-2]  # create path for directory
pOUTPUT = r'/app/IonModel/OUTPUT/'  # Model output directory

FileOutName = ""  # the name of file we want to have

argc = len(sys.argv)  # length of input parameters in terminal

# function to create directories for *.19o/*.19d/*.19d.Z files
def createDir(year, day):
    p = "{0}/{1}/{2}".format(path, year, day)  # path to new file`s folder
    # print("d" + str(not os.path.exists(p)))
    if not os.path.exists(p):
        print("creating directory {0} ... ".format(p))
        try:
            # print("not os.path.exists(p):" + "inside try")
            bashCommand = "mkdir -p {0}".format(p)
            print("bashCommand:" + bashCommand)
            process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            process.wait()
        # print("not os.path.exists(p):" + "inside try before except")
        except OSError as e:
            print(
                "Creation of the directory {0} failed ".format(p) + " error:" + str(e))
        else:
            print("Successfully created the directory {0} ".format(p))
    return p


# function to copy files from to
def cp(pWhat, pWhere):
    shutil.copy2(pWhat, pWhere)


# function to run bash crx2rnx: *.19d to *.19o
def crx2rnx(p, FileName):
    bashCommand = "crx2rnx {0} -f".format(p + "/" + FileName)
    print("bashCommand:" + bashCommand)
    print("p:" + p)
    process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE, cwd=p)  # run bash command
    process.wait()  # wait until process ends


# function to unzip *.19d.Z to *.19d
def unzip(file):
    result = re.split(r'/', file)  # variable to split into slashes FilePath
    FileName = result[len(result) - 1]
    p = createDir(result[len(result) - 3], result[len(result) - 2])
    cp("/{0}/{1}/{2}/{3}/{4}".format(result[1], result[2], result[len(result) - 3], result[len(result) - 2], FileName),
       "{0}".format(p))
    bashCommand = "uncompress -fv {0}/{1}/{2}/{3}".format(path, result[len(result) - 3],
                                                          result[len(result) - 2], FileName)
    print("bashCommand:" + bashCommand)
    process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)  # run bash command
    process.wait()  # wait until process ends
    crx2rnx(p, FileName[:-2])
    return FileName[:-3] + "o", p


if argc < 2:  # incorrect input
    print("Watch -h/--help to see parameters")
    exit(0)
else:
    if sys.argv[1] == "-h" or sys.argv[1] == "--help":  # help
        print("""
		DataChanger.py: Python utility for changing RINEX data
		It changes column value C1/P1 and C2/P2 for each satellite depending on electron density
		Usage:
			DataChanger.py [RINEX_File] [EXIT_File]
			RINEX_File  - incoming file format ./year/day/*.*o  in a directory(data/igs/) (* - 2 last digits in the year number)
			EXIT_File   - exit file name in a specified directory (default /data/IGS/[RINEX_File]_CHANGED.*o) 
		""")
        exit(0)
    elif 1 < argc < 4:  # if the amount of arguments is correct
        for i in range(1, argc):  # iteration through input arguments
            # the 1st argument - FilePath
            if sys.argv[1][0] != "-" and re.findall(r'\D', sys.argv[1]) != []:
                FilePath = FilePath + sys.argv[1]
                try:
                    FileName, p = unzip(FilePath)
                    FileOutName = FileName
                except BaseException as err:
                    print(err)
                    exit(0)
            # the 2nd argument - EXIT_File
            elif i > 1 and sys.argv[i] != "" and sys.argv[i][0] != "-" and re.findall(r'\D', sys.argv[i]) != []:
                FileOutName = sys.argv[i]  # getting the name of ou file
            else:  # incorrect input
                print("Watch -h/--help to see parameters")
                exit(0)
    else:  # incorrect input
        print("Watch -h/--help to see parameters")
        exit(0)

fileR = open(p + r'/' + FileName, "r")  # open new file for reading
# open (if doesn't exists create) file *_CHANGED for writing
fileW = open(p + r'/' + FileName[:-4] + "_CHANGED" + FileName[len(FileName) - 4:], "w")

# frequencies of gps signals
L1 = 1575.42 * 10 ** 6
L2 = 1227.60 * 10 ** 6
L3 = 1381.05 * 10 ** 6
L4 = 1379.913 * 10 ** 6
L5 = 1176.45 * 10 ** 6

currentLine = fileR.readline()  # read next (here first) line of file
TypesOBS = {}  # dict {type of obs:"it`s position in line"}
ReceiverPosition = 0  # starting position of receiver
RinexVersion = 2.11  # version of rinex


# get location of observations in the .19o file
def locateTypesOBS():
    for order, key in zip(range(0, len(TypesOBS.keys()) + 1), TypesOBS.keys()):
        # print("type: " + str(key) + " , j= " + str(order))
        multiplier = order % 5
        TypesOBS[key] = "{0}:{1}".format(multiplier * 16 + 1, multiplier * 16 + 14)
    # print("locateTypesOBS: " + str(TypesOBS))


# calculate Delta for P1/C1
def getDelta(integForEachSat):
    delta = dict()
    for k, v in integForEachSat.items():
        if k[0] == 'G':  # if it is GPS
            delta[k] = dict()
            for key in TypesOBS.keys():
                if key == 'C1' or key == 'P1':  # calculate delta (number to subtract)
                    delta[k][key] = 40.3 * integForEachSat[k] / (L1 ** 2)
                elif key == 'C2' or key == 'P2':
                    delta[k][key] = 40.3 * integForEachSat[k] / (L2 ** 2)
                elif key == 'C3' or key == 'P3':
                    delta[k][key] = 40.3 * integForEachSat[k] / (L3 ** 2)
                elif key == 'C4' or key == 'P4':
                    delta[k][key] = 40.3 * integForEachSat[k] / (L4 ** 2)
                elif key == 'C5' or key == 'P5':
                    delta[k][key] = 40.3 * integForEachSat[k] / (L5 ** 2)
        else:  # other satellite frequency
            delta[k] = dict('')
    return delta


# working with header of the file
while currentLine[60:].rstrip() != "END OF HEADER":
    if currentLine[60:].rstrip() == "RINEX VERSION / TYPE":
        RinexVersion = currentLine[:10].strip()
    elif currentLine[60:].rstrip() == "# / TYPES OF OBSERV":  # reading types of observations
        types = currentLine.split()  # array of words separated by space
        for i in range(len(types)):
            if len(types[i]) == 2 and (  # look for certain observations
                    types[i][0] == "L" or types[i][0] == "S" or types[i][0] == "P" or types[i][0] == "D" or types[i][
                0] == "E" or types[i][0] == "C" or types[i][0] == "I" or types[i][0] == "X"):
                TypesOBS.update({types[i]: ""})
            elif (len(types[i]) == 3) and (  # look for certain observations
                    types[i][0] == "L" or types[i][0] == "S" or types[i][0] == "P" or types[i][0] == "D" or types[i][
                0] == "E" or types[i][0] == "C" or types[i][0] == "I" or types[i][0] == "X") and (
                    types[i][2] == "#"):
                TypesOBS.update({types[i][:-1]: ""})  # write observations in TypesOBS
        locateTypesOBS()  # run function
    elif currentLine[60:].rstrip() == "APPROX POSITION XYZ":  # getting position of receiver
        ReceiverPosition = [currentLine[1:14], currentLine[15:28], currentLine[29:42]]  # ReceiverPosition[x,y,z]
    fileW.write(currentLine)  # write line in fileW
    currentLine = fileR.readline()  # read next line in fileR
fileW.write(currentLine)  # write line in fileW


# function to choose nc file according to time of observation
def ChooseNcFile(year, month, day_of_m, hour, mm, sec):
    oldTime = (datetime.datetime(year, month, day_of_m, hour, mm, sec) - datetime.datetime(2000, 1, 1, 0, 0,
                                                                                           0)).total_seconds()
    file = ""
    for filename in os.listdir(pOUTPUT):  # iterate through files in directory
        if filename.endswith(".nc") and filename.startswith("ModelRunGeo"):
            addDay = 0  # variable to correct day if it is 24 hour
            if int(filename[21:23]) == 24:  # correcting time (24 == 0) and next day
                ncHour = 0
                addDay = 1
            else:
                ncHour = int(filename[21:23])
            # print(datetime.datetime(int(filename[12:16]), 1, 1, 0, 0, 0) + timedelta(int(filename[18:20])))
            if filename.endswith(".nc") and filename.startswith("ModelRunGeo-"):  # check right files
                if filename[17:18] == '0':  # if date of the year < 100
                    t = datetime.datetime(int(filename[12:16]), 1, 1, 0, 0, 0) + timedelta(
                        int(filename[18:20]) + addDay)
                else:  # if date of the year >= 100
                    t = datetime.datetime(int(filename[12:16]), 1, 1, 0, 0, 0) + timedelta(
                        int(filename[17:20]) + addDay)
                # date/time from name of nc file
                ncYear = int(filename[12:16])
                ncMonth = t.month
                ncDay_of_m = t.day
                # ncHour = int(filename[21:23])
                ncMm = int(filename[23:25])
                ncSec = int(filename[25:27])
                newTime = math.fabs((datetime.datetime(year, month, day_of_m, hour, mm, sec) - datetime.datetime(ncYear,
                                                                                                                 ncMonth,
                                                                                                                 ncDay_of_m,
                                                                                                                 ncHour,
                                                                                                                 ncMm,
                                                                                                                 ncSec)).total_seconds())
                if newTime < oldTime:  # search for the most suitable time
                    oldTime = newTime
                    file = filename
        # print("Take: " + str(os.path.join(pOUTPUT, file)))
    return os.path.join(pOUTPUT, file)


# loads files to transfer to integral module for optimizing time
def loadFiles(year, month, day, ModelRunGeo):
    d0 = datetime.datetime(int(year), 1, 1, 00, 00, 00)
    d1 = datetime.datetime(int(year), int(month), int(day))
    delta = (d1 - d0).days + 1
    file = '/data/nav/' + str(year) + '/0' + str(delta) + '/auto0' + str(delta) + '0.19n'

    nav = gr.load(file)  # satellite file

    ncfile = Dataset(ModelRunGeo, 'r')  # ModelRunGeo file
    return nav, ncfile


curDay = -1  # variable to control loading of navfile
navfile = None  # .19n file
ncfile = None  # ModelRunGeo-*.nc file
delta = {}
last_pos = fileR.tell()  # variable to calculate number of bits from starting for loop, needed to return to previous line in case of epoch flag != 0
for line in fileR:  # iterate through lines in file .19o . "for" runs with every new pack of satellites
    lineToWrite = line  # line to be changed and be written in fileW
    if line[27:30] == " 0 " and re.findall(r'\D', line[25:]) != []:  # if line contains time and satellites
        # working with time in this line
        year = int(line[1:3])
        if year < 80:
            year = 2000 + year
        else:
            year = 1900 + year
        month = int(line[4:6])
        day = int(line[7:9])
        hour = int(line[10:12])
        mm = int(line[13:15])
        sec = float(line[16:26])

        numSat = int(line[30:32])  # reading number of satellites
        SatNumbers = []  # reading satellites
        for j in range(numSat // 12):  # in file in 1 line can be no more than 12 satellites. Getting complete lines
            for i in range(12):
                SatNumbers.append(line[32 + i * 3:35 + i * 3])  # append satellite
            if numSat % 12 != 0 or (numSat % 12 == 0 and j != numSat // 12 - 1):
                fileW.write(lineToWrite)  # write to fileW
                last_pos = last_pos + len(line)
                line = fileR.readline()  # read from fileR
                lineToWrite = line  # change line to write
        for i in range(numSat % 12):  # add satellites if them < 12 in line
            SatNumbers.append(line[32 + i * 3:35 + i * 3])  # append satellite
        pFile = ChooseNcFile(int(year), int(month), int(day), int(hour), int(mm), int(sec))  # path to ModelRunGeo*.nc
        if curDay != int(day) or ncfile is None or navfile is None:  # if day in .19o has changed we have to update files .19n and .nc
            navfile, ncfile = loadFiles(int(year), int(month), int(day), pFile)
        print("SatNumbers: " + str(SatNumbers) + " sec:" + str(sec))
        integForEachSat = getIntegral(int(year), int(month), int(day), int(hour), int(mm), int(sec), SatNumbers,
                                      ReceiverPosition[0], ReceiverPosition[1], ReceiverPosition[2], navfile, ncfile)

        print("integForEachSat: " + str(integForEachSat))
        delta = getDelta(integForEachSat)
        curDay = int(day)
    # if epoch flag shows that`s data isn`t ok
    elif line[27:30] == " 1 " or line[27:30] == " 2 " or line[27:30] == " 3 " or line[27:30] == " 4 " or line[27:30] == " 5 " or line[27:30] == " 6 ":
        while line[27:30] != " 0 ":
            fileW.write(lineToWrite)
            last_pos = last_pos + len(line)
            line = fileR.readline()
            lineToWrite = line
        fileR.seek(last_pos)
        continue
    # in other cases if line isn`t empty and line isn`t commented or has less than 5 numbers (fix some problem of stations files)
    elif line != "" and len(re.findall(r'.', line)) > 4 and line[60:].rstrip() != "COMMENT":
        print("START:" + str(line))
        for it, key in zip(range(0, len(delta.keys())), delta.keys()):  # iteration through satellites and number
            print("-----------------NEW SATELLITE:" + key)
            for n, (a, b) in zip(range(0, len(TypesOBS.keys())),
                                 TypesOBS.items()):  # iteration through types of observations and positions of them
                print("-----------------NEW TYPE:" + a)
                for k, v in delta[key].items():  # iteration through observations which have to be changed and how much
                    # if value in line has to be changed and isn`t empty change it
                    if k == a and line[int(b.split(':')[0]):int(b.split(':')[1])].strip() != "":
                        print("satellite:" + str(key) + " change:" + str(v))
                        valOld = line[int(b.split(':')[0]):int(b.split(':')[1])].strip()  # previous value
                        print("valueOld:" + valOld)
                        valNew = str(round(float(valOld) - float(v), 3))  # new value
                        lineToWrite = lineToWrite[0:int(b.split(':')[0]) - 1] + ' ' * (
                                14 - len(valOld)) + valNew + " " * (len(valOld) - len(valNew)) + lineToWrite[
                                                                                                 int(b.split(':')[
                                                                                                         1]):]

                        print("valueNew" + valNew)
                # after every 5th value in row (it is possible to have no more than 5) or it is not the last satellite read new line
                if n % 5 == 4 or n == len(TypesOBS.keys()) - 1:
                    # in case of last satellite only in LAST row don`t read next line ( it will be done in next iteration)
                    if n != len(TypesOBS.keys()) - 1 or (n == len(TypesOBS.keys()) - 1 and it != len(delta.keys()) - 1):
                        fileW.write(lineToWrite)
                        last_pos = last_pos + len(line)
                        line = fileR.readline()
                        lineToWrite = line
    fileW.write(lineToWrite)
    last_pos = last_pos + len(line)
fileR.close()  # close file
fileW.close()  # close file
